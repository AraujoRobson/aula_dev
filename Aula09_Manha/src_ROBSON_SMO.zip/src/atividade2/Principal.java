package atividade2;

public class Principal {

	public static void main(String[] args) {
		
		Elevador elevador = new Elevador();
		
		elevador.inicializa(5, 5);
		elevador.entra();
		elevador.sai();
		elevador.entra();
		elevador.sobe();
		elevador.desce();
		

	}

}
