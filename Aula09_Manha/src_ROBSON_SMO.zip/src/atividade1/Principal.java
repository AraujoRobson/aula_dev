package atividade1;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int codigo;
		Pessoa pessoa = new Pessoa();
		Agenda agenda = new Agenda();
		
		pessoa.setNome("Robson");
		pessoa.setIdade(26);
		pessoa.setAltura(1.72);
		
		agenda.armazenaPessoa(pessoa);
		
		pessoa.setNome("teste");
		pessoa.setIdade(29);
		pessoa.setAltura(1.82);
		
		agenda.armazenaPessoa(pessoa);
		
		pessoa.setNome("Fulano");
		pessoa.setIdade(22);
		pessoa.setAltura(1.89);
		
		agenda.armazenaPessoa(pessoa);
		
		pessoa.setNome("Ciclano");
		pessoa.setIdade(250);
		pessoa.setAltura(2.82);
		
		agenda.armazenaPessoa(pessoa);
		
		agenda.imprimeAgenda();
		
		
		agenda.imprimePessoa(0);
		
		int r = agenda.buscaPessoa("Robson");
		if (r != -1) {
		  System.out.println("C�digo: " + r);
		}else {
			System.out.println("N�o encontrado.");
		}
		
		agenda.removePessoa("Fulano");
		
		agenda.imprimeAgenda();
	}

}
