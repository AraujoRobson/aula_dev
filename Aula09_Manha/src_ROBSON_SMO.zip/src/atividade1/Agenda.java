package atividade1;

import java.util.ArrayList;

public class Agenda {
	private ArrayList<Pessoa> agendaPessoas = new ArrayList<>();
	private int achei;

	public ArrayList<Pessoa> getAgendaPessoas() {
		return agendaPessoas;
	}

	public void setAgendaPessoas(ArrayList<Pessoa> agendaPessoas) {
		this.agendaPessoas = agendaPessoas;
	}

	public void armazenaPessoa(Pessoa p) {
		if (agendaPessoas.size() < 10) {
			agendaPessoas.add(new Pessoa(p.getNome(), p.getIdade(), p.getAltura()));
		} else {
			System.out.println("Agenda cheia!");
		}
	}

	void removePessoa(String nome) {
		System.out.println();
		for (int i = 0; i < agendaPessoas.size(); i++) {
			if (nome == agendaPessoas.get(i).getNome()) {
				agendaPessoas.remove(i);
				break;
			}
		}

	}

	public int buscaPessoa(String nome) {
		System.out.println();
		System.out.println("Mostrando c�digo da agenda: ");
		for (int i = 0; i < agendaPessoas.size(); i++) {
			if (nome == agendaPessoas.get(i).getNome()) {
				return i + 1;
			}
		}
		return -1;

	}

	void imprimeAgenda() {
		System.out.println();
		System.out.println("Mostrando agenda de pessoas...");
		for (int i = 0; i < agendaPessoas.size(); i++) {
			System.out.println("C�digo: " + (i + 1) + ", Nome: " + agendaPessoas.get(i).getNome() + ", Idade: "
					+ agendaPessoas.get(i).getIdade() + ", Altura: " + agendaPessoas.get(i).getAltura());
		}
	}

	void imprimePessoa(int index) {
		System.out.println();
		System.out.println("Mostrando agenda pelo c�digo informado: ");
		System.out.println("Nome: " + agendaPessoas.get(index).getNome() + ", Idade: "
				+ agendaPessoas.get(index).getIdade() + ", Altura: " + agendaPessoas.get(index).getAltura());
	}

}
